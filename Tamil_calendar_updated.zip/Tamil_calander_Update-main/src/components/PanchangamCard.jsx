import React from "react";
import { Paper, Box, Typography, Grid, Stack } from "@mui/material";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import { format } from "date-fns";
import { getPanchangam } from "./utils/panchangam";

const items = [
  { key: "rahuKalam", label: "Rahu Kalam" },
  { key: "yamagandam", label: "Yamagandam" },
  { key: "gulikaKalam", label: "Gulika Kalam" },
];

export default function PanchangamCard() {
  const today = new Date();
  const pancha = getPanchangam(today);

  return (
    <Paper
      elevation={0}
      sx={{
        p: { xs: 2, sm: 2.5 },
        mb: 3,
        borderRadius: 4,
        background: "linear-gradient(135deg, #ede7f6 0%, #e0f7fa 100%)",
        border: "1px solid rgba(103,58,183,0.12)",
      }}
    >
      <Stack direction="row" alignItems="center" spacing={1.5} sx={{ mb: 1.5 }}>
        <AccessTimeIcon sx={{ color: "#673ab7" }} />
        <Box>
          <Typography variant="subtitle1" fontWeight={600}>
            {format(today, "MMMM d, yyyy")}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {pancha.weekday}
          </Typography>
        </Box>
      </Stack>

      <Grid container spacing={1.5}>
        {items.map((item) => (
          <Grid item xs={12} sm={4} key={item.key}>
            <Box
              sx={{
                bgcolor: "rgba(255,255,255,0.7)",
                borderRadius: 2,
                px: 1.5,
                py: 1,
              }}
            >
              <Typography
                variant="caption"
                color="text.secondary"
                sx={{ textTransform: "uppercase", letterSpacing: 0.3 }}
              >
                {item.label}
              </Typography>
              <Typography variant="body2" fontWeight={600} color="#c62828">
                {pancha[item.key]}
              </Typography>
            </Box>
          </Grid>
        ))}
      </Grid>

      <Typography
        variant="caption"
        color="text.secondary"
        sx={{ display: "block", mt: 1.5, textAlign: "center" }}
      >
        Standard weekday windows (assumes ~6 AM - 6 PM daylight). Approximate -
        exact timings shift daily with local sunrise/sunset.
      </Typography>
    </Paper>
  );
}
