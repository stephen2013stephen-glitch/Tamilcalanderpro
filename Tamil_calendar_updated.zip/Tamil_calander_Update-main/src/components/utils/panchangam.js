/**
 * Panchangam utility
 *
 * Rahu Kalam, Yamagandam, and Gulika Kalam are traditionally computed from
 * that day's actual sunrise/sunset, so exact windows shift daily and by
 * location. The tables below are the standard weekday approximations
 * (assuming a ~6:00 AM - 6:00 PM daylight window) that most printed Tamil
 * panchangams use as a quick reference. For location-exact timings, a real
 * sunrise/sunset + ephemeris calculation is needed.
 */

export const weekdayNames = [
  "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
];

// Index = date.getDay() (0 = Sunday ... 6 = Saturday)
export const rahuKalam = [
  "16:30 - 18:00", // Sunday
  "07:30 - 09:00", // Monday
  "15:00 - 16:30", // Tuesday
  "12:00 - 13:30", // Wednesday
  "13:30 - 15:00", // Thursday
  "10:30 - 12:00", // Friday
  "09:00 - 10:30", // Saturday
];

export const yamagandam = [
  "12:00 - 13:30", // Sunday
  "10:30 - 12:00", // Monday
  "09:00 - 10:30", // Tuesday
  "07:30 - 09:00", // Wednesday
  "06:00 - 07:30", // Thursday
  "15:00 - 16:30", // Friday
  "13:30 - 15:00", // Saturday
];

export const gulikaKalam = [
  "15:00 - 16:30", // Sunday
  "13:30 - 15:00", // Monday
  "12:00 - 13:30", // Tuesday
  "10:30 - 12:00", // Wednesday
  "09:00 - 10:30", // Thursday
  "07:30 - 09:00", // Friday
  "06:00 - 07:30", // Saturday
];

/**
 * Returns the approximate panchangam windows for a given date.
 * @param {Date} date
 */
export function getPanchangam(date) {
  const day = date.getDay();
  return {
    weekday: weekdayNames[day],
    rahuKalam: rahuKalam[day],
    yamagandam: yamagandam[day],
    gulikaKalam: gulikaKalam[day],
  };
}
